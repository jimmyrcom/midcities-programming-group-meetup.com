package com.Jimmyr.prs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;


public class MyActivity extends ActionBarActivity implements OnClickListener {
    private static final String TAG = "MyActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        findViewById(R.id.rock).setOnClickListener(this);
        findViewById(R.id.paper).setOnClickListener(this);
        findViewById(R.id.scissors).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
       int computerChoice = (int)(Math.random()*10) % 3;
       int[] images = {R.drawable.rock, R.drawable.paper, R.drawable.scissors};
       ImageView computerAnswer = (ImageView) findViewById(R.id.computerAnswer);
       int computerNumericSelectedAnswer= images[computerChoice];
       computerAnswer.setImageResource(computerNumericSelectedAnswer);

       ImageView myAnswerImage = (ImageView) findViewById(R.id.myAnswer);
       int myAnswer = view.getId();
       if (myAnswer == R.id.rock) myAnswerImage.setImageResource(R.drawable.rock);
       if (myAnswer == R.id.paper) myAnswerImage.setImageResource(R.drawable.paper);
       if (myAnswer == R.id.scissors) myAnswerImage.setImageResource(R.drawable.scissors);

        int myAnswerNumber;
        switch(myAnswer){
           case R.id.rock: myAnswerNumber =0; break;
           case R.id.paper: myAnswerNumber =1; break;
           default: myAnswerNumber=2; break;
        }
       //int myAnswerNumber = (myAnswer == R.id.rock) ? 0 : (myAnswer == R.id.paper) ? 1 : 2;
       // 0 Rock, 1 is paper, 2 is scissors
        if (myAnswerNumber == computerChoice) Log("Draw!");
        //rock vs paper
        else if (myAnswerNumber == 0 && computerChoice == 1) Log("Lose!");
        else if (myAnswerNumber == 1 && computerChoice == 2) Log("Lose!");
        else if (myAnswerNumber == 2 && computerChoice == 0) Log("Lose!");
        else Log("You win!");

    }
    /*
    public void Log(String msg){
           Log.e(TAG,msg);
    }*/

    public void Log(String msg){
        AlertDialog.Builder builder = new AlertDialog.Builder(MyActivity.this);
        builder.setMessage(msg);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which){
            //delete files
            };
        });
        builder.create().show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
