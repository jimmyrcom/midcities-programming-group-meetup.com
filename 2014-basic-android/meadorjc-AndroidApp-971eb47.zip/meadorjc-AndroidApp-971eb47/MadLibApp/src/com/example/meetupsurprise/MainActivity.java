package com.example.meetupsurprise;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends Activity {

	public final static String EXTRA_MESSAGE="com.example.meetupsurprise.MESSAGE";
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    public void sendMessage(View view) {
    	Intent intent = new Intent(this, DisplayMessageActivity.class);
    	EditText editText1 = (EditText) findViewById(R.id.edit_message1);
    	EditText editText2 = (EditText) findViewById(R.id.edit_message2);
    	EditText editText3 = (EditText) findViewById(R.id.edit_message3);
    	EditText editText4 = (EditText) findViewById(R.id.edit_message4);
    	EditText editText5 = (EditText) findViewById(R.id.edit_message5);
    	String message = "There once was a "
    				+ editText1.getText().toString() //adj
    				+ " "
    				+ editText2.getText().toString() //noun
    				+" named Jimmy, who "
    				+ editText3.getText().toString() //verb (past)
    				+ " on a plane to SimCity, he "
    				+ editText4.getText().toString() //verb (past)
    				+ " in a train, and said 'What a pain! I'm "
    				+ editText5.getText().toString() //(-ing verb)
    				+ " no more for a day!";
    	
    	//adj noun verb(past) verb(past) (-ing verb)
    	intent.putExtra(EXTRA_MESSAGE, message);
    	startActivity(intent);
    	
    	
    }
    
}
